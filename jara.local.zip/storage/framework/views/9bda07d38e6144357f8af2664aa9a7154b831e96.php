<h3>Hello, message from your site</h3>

<p>customer: <?php echo e($custName); ?></p>
<p>customer email: <?php echo e($email); ?> </p>
<p>customer phone: <?php echo e($phone); ?> </p>

<p><b>Message body:</b></p>
<p><?php echo e($text); ?></p>
