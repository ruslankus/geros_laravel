<!doctype html>
<html>
<head>
   <?php echo $__env->yieldContent('head'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
<script src="js/jquery-2.2.0.js"></script>
<script src="js/common.js" ></script>
</html>
