<!doctype html>
<html>
<head>
   @yield('head')
</head>

<body>
    @yield('content')
</body>
<script src="js/jquery-2.2.0.js"></script>
<script src="js/common.js" ></script>
</html>
