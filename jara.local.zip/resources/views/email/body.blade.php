<h3>Hello, message from your site</h3>

<p>customer: {{ $custName }}</p>
<p>customer email: {{ $email }} </p>
<p>customer phone: {{ $phone }} </p>

<p><b>Message body:</b></p>
<p>{{ $text }}</p>
